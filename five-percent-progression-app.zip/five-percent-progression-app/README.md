# 5% Progression App

This app calculates a safe 5% weekly progression from a baseline value over a set number of weeks — useful in rehab, training, or physical therapy.

## How to Run

```bash
npm install
npm start
```

## Features

- Set baseline and week count
- Outputs week-by-week progressive values
