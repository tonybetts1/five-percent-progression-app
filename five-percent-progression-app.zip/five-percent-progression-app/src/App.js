import React, { useState } from 'react';

function App() {
  const [baseline, setBaseline] = useState(100);
  const [weeks, setWeeks] = useState(12);
  const [progression, setProgression] = useState([]);

  const calculateProgression = () => {
    const result = [];
    let current = parseFloat(baseline);
    for (let i = 1; i <= weeks; i++) {
      current += current * 0.05;
      result.push({ week: i, value: parseFloat(current.toFixed(2)) });
    }
    setProgression(result);
  };

  return (
    <div style={{ padding: 20, fontFamily: 'Arial, sans-serif' }}>
      <h1>5% Weekly Progression Calculator</h1>
      <label>
        Baseline Value:
        <input
          type="number"
          value={baseline}
          onChange={(e) => setBaseline(e.target.value)}
          style={{ margin: '0 10px' }}
        />
      </label>
      <label>
        Weeks:
        <input
          type="number"
          value={weeks}
          onChange={(e) => setWeeks(e.target.value)}
          style={{ margin: '0 10px' }}
        />
      </label>
      <button onClick={calculateProgression}>Calculate</button>

      {progression.length > 0 && (
        <table border="1" style={{ marginTop: 20 }}>
          <thead>
            <tr>
              <th>Week</th>
              <th>Value</th>
            </tr>
          </thead>
          <tbody>
            {progression.map((entry) => (
              <tr key={entry.week}>
                <td>{entry.week}</td>
                <td>{entry.value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default App;