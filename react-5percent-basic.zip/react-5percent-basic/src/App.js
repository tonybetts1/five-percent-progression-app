import React, { useState } from "react";

function App() {
  const [baseline, setBaseline] = useState(100);
  const [weeks, setWeeks] = useState(12);
  const [data, setData] = useState([]);

  const handleCalc = () => {
    let val = parseFloat(baseline);
    const result = [];
    for (let i = 1; i <= weeks; i++) {
      val += val * 0.05;
      result.push(`Week ${i}: ${val.toFixed(2)}`);
    }
    setData(result);
  };

  return (
    <div style={{ padding: "1rem", fontFamily: "sans-serif" }}>
      <h2>5% Progression Tool</h2>
      <div>
        <label>Baseline: </label>
        <input type="number" value={baseline} onChange={e => setBaseline(e.target.value)} />
      </div>
      <div>
        <label>Weeks: </label>
        <input type="number" value={weeks} onChange={e => setWeeks(e.target.value)} />
      </div>
      <button onClick={handleCalc}>Calculate</button>
      <ul>
        {data.map((item, idx) => <li key={idx}>{item}</li>)}
      </ul>
    </div>
  );
}

export default App;
